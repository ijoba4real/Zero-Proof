pragma circom 2.1.0;

include "../node_modules/circomlib/circuits/poseidon.circom";
include "../node_modules/circomlib/circuits/comparators.circom";
include "../node_modules/circomlib/circuits/mux1.circom";

// Same Merkle-inclusion building blocks as age_eligibility.circom (kept
// identical on purpose, so the two circuits are directly comparable).
template MerkleLevel() {
    signal input node;
    signal input sibling;
    signal input pathIndex;
    signal output parent;

    pathIndex * (pathIndex - 1) === 0;

    component left  = Mux1();
    component right = Mux1();
    left.c[0]  <== node;
    left.c[1]  <== sibling;
    left.s     <== pathIndex;

    right.c[0] <== sibling;
    right.c[1] <== node;
    right.s    <== pathIndex;

    component h = Poseidon(2);
    h.inputs[0] <== left.out;
    h.inputs[1] <== right.out;
    parent <== h.out;
}

template MerkleProof(depth) {
    signal input leaf;
    signal input pathElements[depth];
    signal input pathIndices[depth];
    signal input root;

    component levels[depth];
    signal cur[depth + 1];
    cur[0] <== leaf;

    for (var i = 0; i < depth; i++) {
        levels[i] = MerkleLevel();
        levels[i].node        <== cur[i];
        levels[i].sibling      <== pathElements[i];
        levels[i].pathIndex    <== pathIndices[i];
        cur[i + 1] <== levels[i].parent;
    }
    cur[depth] === root;
}

// Equality-check predicate circuit (Section 4.2's second and third scenarios:
// a vehicle-ownership match, and a financial KYC status check). Both reduce
// to the same shape: prove a committed private attribute equals a publicly
// stated target value, and that the commitment is included, unrevoked, in
// the current Merkle-accumulator root -- without revealing the attribute
// value itself beyond the fact that it equals the target.
template EqualityPredicate(depth) {
    // Private witness
    signal input attributeValue;    // e.g. the holder's KYC-tier code, or an ownership record hash
    signal input randomness;
    signal input pathElements[depth];
    signal input pathIndices[depth];

    // Public statement x = (commitment, root, targetValue)
    signal input commitment;
    signal input root;
    signal input targetValue;

    signal output valid;

    component commit = Poseidon(2);
    commit.inputs[0] <== attributeValue;
    commit.inputs[1] <== randomness;
    commit.out === commitment;

    component leafHash = Poseidon(1);
    leafHash.inputs[0] <== commitment;

    component merkle = MerkleProof(depth);
    merkle.leaf <== leafHash.out;
    merkle.root <== root;
    for (var i = 0; i < depth; i++) {
        merkle.pathElements[i] <== pathElements[i];
        merkle.pathIndices[i]  <== pathIndices[i];
    }

    // attributeValue == targetValue, without ever exposing attributeValue
    component eq = IsEqual();
    eq.in[0] <== attributeValue;
    eq.in[1] <== targetValue;
    eq.out === 1;

    valid <== 1;
}

component main {public [commitment, root, targetValue]} = EqualityPredicate(10);
