pragma circom 2.1.0;

include "../node_modules/circomlib/circuits/poseidon.circom";
include "../node_modules/circomlib/circuits/comparators.circom";
include "../node_modules/circomlib/circuits/mux1.circom";

// One level of a Merkle inclusion proof: given the current node value and a
// sibling, hash them in the order indicated by pathIndex (0 = current node is
// the left child, 1 = current node is the right child).
template MerkleLevel() {
    signal input node;
    signal input sibling;
    signal input pathIndex;     // must be boolean, enforced below
    signal output parent;

    pathIndex * (pathIndex - 1) === 0;

    component left  = Mux1();
    component right = Mux1();
    left.c[0]  <== node;
    left.c[1]  <== sibling;
    left.s     <== pathIndex;

    right.c[0] <== sibling;
    right.c[1] <== node;
    right.s    <== pathIndex;

    component h = Poseidon(2);
    h.inputs[0] <== left.out;
    h.inputs[1] <== right.out;
    parent <== h.out;
}

// Full Merkle inclusion check against a public root, for a tree of the given depth.
template MerkleProof(depth) {
    signal input leaf;
    signal input pathElements[depth];
    signal input pathIndices[depth];
    signal input root;

    component levels[depth];
    signal cur[depth + 1];
    cur[0] <== leaf;

    for (var i = 0; i < depth; i++) {
        levels[i] = MerkleLevel();
        levels[i].node        <== cur[i];
        levels[i].sibling      <== pathElements[i];
        levels[i].pathIndex    <== pathIndices[i];
        cur[i + 1] <== levels[i].parent;
    }

    // Equality is enforced, not just computed: a tampered root or a bad path
    // fails right here, before any proof could be attempted (Section 6).
    cur[depth] === root;
}

// Age-eligibility predicate circuit (Section 4.2 / 5): proves that a holder's
// committed age meets a public threshold and that the commitment is present,
// unrevoked, in the current Merkle-accumulator root -- without revealing the
// age itself. Depth is fixed per compiled variant (this paper: 4, 7, 10, 12, 14).
template AgeEligibility(depth) {
    // Private witness
    signal input age;               // the holder's actual attribute value
    signal input randomness;        // commitment randomness r
    signal input pathElements[depth];
    signal input pathIndices[depth];

    // Public statement x = (commitment, root, threshold)
    signal input commitment;
    signal input root;
    signal input threshold;

    signal output valid;

    // c = Poseidon(age, randomness) must match the publicly presented commitment
    component commit = Poseidon(2);
    commit.inputs[0] <== age;
    commit.inputs[1] <== randomness;
    commit.out === commitment;

    // Merkle inclusion of the commitment (as a leaf) under the current root
    component leafHash = Poseidon(1);
    leafHash.inputs[0] <== commitment;

    component merkle = MerkleProof(depth);
    merkle.leaf <== leafHash.out;
    merkle.root <== root;
    for (var i = 0; i < depth; i++) {
        merkle.pathElements[i] <== pathElements[i];
        merkle.pathIndices[i]  <== pathIndices[i];
    }

    // age >= threshold, without ever exposing age itself
    component geq = GreaterEqThan(32);
    geq.in[0] <== age;
    geq.in[1] <== threshold;
    geq.out === 1;

    valid <== 1;
}

component main {public [commitment, root, threshold]} = AgeEligibility(10);
