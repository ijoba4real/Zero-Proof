#!/usr/bin/env bash
# Compiles, sets up, and tests circuits/equality_predicate.circom -- the
# second predicate circuit (covers the vehicle-ownership-match and
# financial-KYC-status scenarios, which share the same equality-check shape).
# Run after 01_build.sh / 02_setup.sh, or standalone: it runs its own
# Powers of Tau ceremony rather than reusing build/ptau.
set -euo pipefail
cd "$(dirname "$0")/.."

mkdir -p build_eq ptau2

circom circuits/equality_predicate.circom --r1cs --wasm --sym -o build_eq

cd ptau2
snarkjs powersoftau new bn128 13 pot13_0000.ptau
echo "eq-circuit-$(date -u +%Y%m%dT%H%M%SZ)" | \
  snarkjs powersoftau contribute pot13_0000.ptau pot13_0001.ptau --name="eq circuit contribution"
snarkjs powersoftau prepare phase2 pot13_0001.ptau pot13_final.ptau
cd ..

cd build_eq
snarkjs groth16 setup equality_predicate.r1cs ../ptau2/pot13_final.ptau equality_predicate_0000.zkey
echo "eq-zkey-$(date -u +%Y%m%dT%H%M%SZ)" | \
  snarkjs zkey contribute equality_predicate_0000.zkey equality_predicate_final.zkey --name="eq zkey contribution"
snarkjs zkey export verificationkey equality_predicate_final.zkey verification_key.json
cd ..

node scripts/build_eq_inputs.js

cd build_eq
echo "=== Valid case: KYC tier 2, target 2 ==="
node equality_predicate_js/generate_witness.js equality_predicate_js/equality_predicate.wasm inputs/input_valid.json witness_valid.wtns
snarkjs groth16 prove equality_predicate_final.zkey witness_valid.wtns proof.json public.json
snarkjs groth16 verify verification_key.json public.json proof.json

echo ""
echo "=== Negative test: mismatched target value (expected to fail) ==="
python3 -c "
import json
d = json.load(open('inputs/input_valid.json'))
d['targetValue'] = '3'
json.dump(d, open('inputs/input_mismatch.json', 'w'), indent=2)
"
node equality_predicate_js/generate_witness.js equality_predicate_js/equality_predicate.wasm inputs/input_mismatch.json witness_mismatch.wtns \
  && echo "UNEXPECTED: witness generation succeeded" || echo "Failed as expected (see assertion trace above)."
