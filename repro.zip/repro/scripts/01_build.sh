#!/usr/bin/env bash
# Compiles circuits/age_eligibility.circom with circom 2.2.3.
# Requires: circom 2.2.3 on PATH, and `npm install` run in the project root
# (circomlib for the circuit includes, circomlibjs for the JS-side Merkle tree).
set -euo pipefail
cd "$(dirname "$0")/.."

mkdir -p build
circom circuits/age_eligibility.circom --r1cs --wasm --sym -o build
echo "Compiled: build/age_eligibility.r1cs, build/age_eligibility_js/age_eligibility.wasm"
