// Builds a genuine depth-10 (1024-leaf) Poseidon Merkle tree, plants one
// real holder commitment (age 27) as a leaf, and writes out three witness
// input files: a valid case, and the two negative-case soundness tests
// described in the paper (underage claim, tampered/stale root).
const fs = require("fs");
const path = require("path");
const circomlibjs = require("circomlibjs");

async function main() {
  const poseidon = await circomlibjs.buildPoseidon();
  const F = poseidon.F;
  const H = (arr) => F.toObject(poseidon(arr));

  const depth = 10;
  const nLeaves = 2 ** depth; // 1024

  // Genuine holder: age 27, some randomness, real commitment
  const age = 27n;
  const randomness = 123456789012345n;
  const commitment = H([age, randomness]);
  const leafValue = H([commitment]);

  // Fill the rest of the tree with filler leaves (Poseidon of index, as stand-ins
  // for other enrolled holders' commitments -- not real attribute data), except
  // for a second genuine holder (age 15) planted for the underage negative test.
  const leaves = [];
  const holderIndex = 42;   // our genuine adult holder
  const minorIndex = 900;   // a second genuine holder, a minor, for the negative test

  const minorAge = 15n;
  const minorRandomness = 55555n;
  const minorCommitment = H([minorAge, minorRandomness]);
  const minorLeafValue = H([minorCommitment]);

  for (let i = 0; i < nLeaves; i++) {
    if (i === holderIndex) {
      leaves.push(leafValue);
    } else if (i === minorIndex) {
      leaves.push(minorLeafValue);
    } else {
      leaves.push(H([BigInt(i), 999999n]));
    }
  }

  function computePath(leavesArr, leafIndex) {
    let level = leavesArr.slice();
    const elems = [];
    const idxs = [];
    let i = leafIndex;
    for (let d = 0; d < depth; d++) {
      const isRight = i % 2;
      const siblingIdx = isRight ? i - 1 : i + 1;
      elems.push(level[siblingIdx]);
      idxs.push(isRight);
      const next = [];
      for (let j = 0; j < level.length; j += 2) {
        next.push(H([level[j], level[j + 1]]));
      }
      level = next;
      i = Math.floor(i / 2);
    }
    return { pathElements: elems, pathIndices: idxs, root: level[0] };
  }

  const adultPath = computePath(leaves, holderIndex);
  const minorPath = computePath(leaves, minorIndex);
  const pathElements = adultPath.pathElements;
  const pathIndices = adultPath.pathIndices;
  const root = adultPath.root; // same root either way; both leaves are in the same tree

  const toStr = (x) => x.toString();

  // --- Case 1: genuine, valid witness ---
  const valid = {
    age: toStr(age),
    randomness: toStr(randomness),
    pathElements: pathElements.map(toStr),
    pathIndices: pathIndices.map(toStr),
    commitment: toStr(commitment),
    root: toStr(root),
    threshold: "18",
  };

  // --- Case 2: negative test, underage claim (genuine leaf, age 15 vs threshold 18) ---
  const underage = {
    age: toStr(minorAge),
    randomness: toStr(minorRandomness),
    // this holder's own genuine Merkle path -- commitment and inclusion both
    // check out; only the age comparator should fail
    pathElements: minorPath.pathElements.map(toStr),
    pathIndices: minorPath.pathIndices.map(toStr),
    commitment: toStr(minorCommitment),
    root: toStr(root),
    threshold: "18",
  };

  // --- Case 3: negative test, stale/tampered revocation root ---
  const staleRoot = (BigInt(root) + 1n).toString();
  const tamperedRoot = {
    age: toStr(age),
    randomness: toStr(randomness),
    pathElements: pathElements.map(toStr),
    pathIndices: pathIndices.map(toStr),
    commitment: toStr(commitment),
    root: staleRoot,
    threshold: "18",
  };

  const outDir = path.join(__dirname, "..", "build", "inputs");
  fs.mkdirSync(outDir, { recursive: true });
  fs.writeFileSync(path.join(outDir, "input_valid.json"), JSON.stringify(valid, null, 2));
  fs.writeFileSync(path.join(outDir, "input_underage.json"), JSON.stringify(underage, null, 2));
  fs.writeFileSync(path.join(outDir, "input_stale_root.json"), JSON.stringify(tamperedRoot, null, 2));

  console.log("Merkle root:", root.toString());
  console.log("Genuine commitment:", commitment.toString());
  console.log("Wrote input_valid.json, input_underage.json, input_stale_root.json to", outDir);
}

main().catch((e) => { console.error(e); process.exit(1); });
