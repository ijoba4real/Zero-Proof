const fs = require("fs");
const path = require("path");
const circomlibjs = require("circomlibjs");

async function main() {
  const poseidon = await circomlibjs.buildPoseidon();
  const F = poseidon.F;
  const H = (arr) => F.toObject(poseidon(arr));

  const depth = 10;
  const nLeaves = 2 ** depth;

  // Genuine holder: KYC tier code 2 ("verified"), matching the target the
  // verifier is checking for.
  const kycTier = 2n;
  const randomness = 987654321098765n;
  const commitment = H([kycTier, randomness]);
  const leafValue = H([commitment]);

  const leaves = [];
  const holderIndex = 77;
  for (let i = 0; i < nLeaves; i++) {
    leaves.push(i === holderIndex ? leafValue : H([BigInt(i), 424242n]));
  }

  let level = leaves;
  const pathElements = [];
  const pathIndices = [];
  let idx = holderIndex;
  for (let d = 0; d < depth; d++) {
    const isRight = idx % 2;
    const siblingIdx = isRight ? idx - 1 : idx + 1;
    pathElements.push(level[siblingIdx]);
    pathIndices.push(isRight);
    const next = [];
    for (let i = 0; i < level.length; i += 2) next.push(H([level[i], level[i + 1]]));
    level = next;
    idx = Math.floor(idx / 2);
  }
  const root = level[0];
  const toStr = (x) => x.toString();

  const valid = {
    attributeValue: toStr(kycTier),
    randomness: toStr(randomness),
    pathElements: pathElements.map(toStr),
    pathIndices: pathIndices.map(toStr),
    commitment: toStr(commitment),
    root: toStr(root),
    targetValue: "2",
  };

  const outDir = path.join(__dirname, "..", "build_eq", "inputs");
  fs.mkdirSync(outDir, { recursive: true });
  fs.writeFileSync(path.join(outDir, "input_valid.json"), JSON.stringify(valid, null, 2));
  console.log("Merkle root:", root.toString());
  console.log("Wrote input_valid.json to", outDir);
}

main().catch((e) => { console.error(e); process.exit(1); });
