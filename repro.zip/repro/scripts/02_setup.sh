#!/usr/bin/env bash
# Runs a single-participant Groth16 trusted setup (Powers of Tau phase 1,
# phase 2 preparation, circuit-specific setup, and one zkey contribution).
#
# IMPORTANT, as the paper itself discloses for its own setup: this is a
# single-participant demonstration ceremony, not the multi-party ceremony a
# real deployment needs (see the paper's Section 9.1). Anyone reusing this
# script for anything beyond reproducing the paper's methodology must run a
# genuine multi-party Powers of Tau contribution instead.
set -euo pipefail
cd "$(dirname "$0")/.."

mkdir -p build/ptau
cd build

snarkjs powersoftau new bn128 13 ptau/pot13_0000.ptau -v
echo "reproducibility-artifact-$(date -u +%Y%m%dT%H%M%SZ)" | \
  snarkjs powersoftau contribute ptau/pot13_0000.ptau ptau/pot13_0001.ptau \
  --name="repro artifact single contribution" -v
snarkjs powersoftau prepare phase2 ptau/pot13_0001.ptau ptau/pot13_final.ptau -v

snarkjs groth16 setup age_eligibility.r1cs ptau/pot13_final.ptau age_eligibility_0000.zkey
echo "reproducibility-artifact-zkey-$(date -u +%Y%m%dT%H%M%SZ)" | \
  snarkjs zkey contribute age_eligibility_0000.zkey age_eligibility_final.zkey \
  --name="repro artifact zkey contribution" -v
snarkjs zkey export verificationkey age_eligibility_final.zkey verification_key.json

echo "Setup complete: build/age_eligibility_final.zkey, build/verification_key.json"
