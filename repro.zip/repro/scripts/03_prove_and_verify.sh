#!/usr/bin/env bash
# Builds the Merkle tree and witness inputs, then for the valid case generates
# and verifies a real Groth16 proof, and for the two negative-case soundness
# tests confirms witness generation fails at the expected constraint.
set -euo pipefail
cd "$(dirname "$0")/.."

node scripts/build_merkle_and_inputs.js

cd build
WASM=age_eligibility_js/age_eligibility.wasm

echo "=== Valid case: genuine holder, age 27, threshold 18 ==="
node age_eligibility_js/generate_witness.js "$WASM" inputs/input_valid.json witness_valid.wtns
snarkjs groth16 prove age_eligibility_final.zkey witness_valid.wtns proof.json public.json
snarkjs groth16 verify verification_key.json public.json proof.json

echo ""
echo "=== Negative test 1: underage claim (age 15 vs threshold 18) ==="
echo "Expected: witness generation fails at the age-comparator assertion."
node age_eligibility_js/generate_witness.js "$WASM" inputs/input_underage.json witness_underage.wtns \
  && echo "UNEXPECTED: witness generation succeeded" || echo "Failed as expected (see assertion trace above)."

echo ""
echo "=== Negative test 2: stale/tampered revocation root ==="
echo "Expected: witness generation fails at the Merkle-equality assertion."
node age_eligibility_js/generate_witness.js "$WASM" inputs/input_stale_root.json witness_stale.wtns \
  && echo "UNEXPECTED: witness generation succeeded" || echo "Failed as expected (see assertion trace above)."
